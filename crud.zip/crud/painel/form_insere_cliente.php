<?php
    session_start();
    if((!isset($_SESSION['id']) == true) and (!isset($_SESSION['nome']) == true) and (!isset($_SESSION['email']) == true)){
        unset($_SESSION['id']);
        unset($_SESSION['nome']);
        unset($_SESSION['email']);
        header('Location: ../index.html');
    }
    require('conecta.php');

?>
<?php
    include_once('cabecalho.php');
?>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
        <div class="content mt-3">

            <!--/.col-->
            <div class="col-sm-8">
                <div class="card">
                    <form action="insere_cliente.php" method="POST">
                        <h1>Inserir Cliente</h1>
                        <div class="mb-3">
                            <label for="nome_cliente" class="form-label">Nome do Cliente</label>
                            <input type="text" class="form-control" id="nome_cliente" name="nome_cliente" placeholder="Nome">                            
                        </div>
                        <div class="mb-3">
                            <label for="email_cliente" class="form-label">Email do cliente</label>
                            <input type="email" class="form-control" id="email_cliente" name="email_cliente" placeholder="Email">
                        </div>
                        <div class="mb-3">
                            <label for="cidade" class="form-label">Cidade do cliente</label>
                            <input type="text" class="form-control" id="cidade" name="cidade" placeholder="Cidade">
                        </div>                        
                        <button type="submit" class="btn btn-primary">Cadastrar</button>
                    </form>
                </div>
            </div>
            <!--/.col-->
        </div> <!-- .content -->
    </div><!-- /#right-panel -->
    <!-- Fim Painel Direito -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>
